import 'package:flutter/material.dart';



class MeasuresConverterApp extends StatelessWidget {
  const MeasuresConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Measures Converter',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MeasuresConverterScreen(),
    );
  }
}

class MeasuresConverterScreen extends StatefulWidget {
  const MeasuresConverterScreen({super.key});

  @override
  State<MeasuresConverterScreen> createState() => _MeasuresConverterScreenState();
}

class _MeasuresConverterScreenState extends State<MeasuresConverterScreen> {
  final TextEditingController _valueController = TextEditingController();
  String _fromUnit = 'meters';
  String _toUnit = 'feet';
  String _result = '';
  String _category = 'Distance'; // Default category: Distance or Weight

  // Conversion factors
  final Map<String, double> _distanceConversions = {
    'meters': 1.0,
    'kilometers': 1000.0,
    'miles': 1609.34,
    'feet': 0.3048,
  };

  final Map<String, double> _weightConversions = {
    'kilograms': 1.0,
    'pounds': 0.453592,
    'grams': 0.001,
    'ounces': 0.0283495,
  };

  List<String> _getUnits() {
    if (_category == 'Distance') {
      return _distanceConversions.keys.toList();
    } else {
      return _weightConversions.keys.toList();
    }
  }

  void _convert() {
    if (_valueController.text.isEmpty) {
      setState(() {
        _result = 'Please enter a value';
      });
      return;
    }

    double value = double.tryParse(_valueController.text) ?? 0.0;
    double result;

    if (_category == 'Distance') {
      // Convert from the "from" unit to meters first
      double toMeters = value * (1 / _distanceConversions[_fromUnit]!);
      // Convert from meters to the "to" unit
      result = toMeters * _distanceConversions[_toUnit]!;
    } else {
      // Convert from the "from" unit to kilograms first
      double toKilograms = value * (1 / _weightConversions[_fromUnit]!);
      // Convert from kilograms to the "to" unit
      result = toKilograms * _weightConversions[_toUnit]!;
    }

    setState(() {
      _result = '$value $_fromUnit are ${result.toStringAsFixed(3)} $_toUnit';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Measures Converter'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Category selector
            DropdownButton<String>(
              value: _category,
              isExpanded: true,
              items: ['Distance', 'Weight']
                  .map((category) => DropdownMenuItem(
                value: category,
                child: Text(category),
              ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _category = value!;
                  // Reset units when category changes
                  _fromUnit = _getUnits().first;
                  _toUnit = _getUnits().first;
                  _result = '';
                });
              },
            ),
            const SizedBox(height: 20),
            const Text('Value', style: TextStyle(fontSize: 16, color: Colors.grey)),
            TextField(
              controller: _valueController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                border: UnderlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            const Text('From', style: TextStyle(fontSize: 16, color: Colors.grey)),
            DropdownButton<String>(
              value: _fromUnit,
              isExpanded: true,
              items: _getUnits()
                  .map((unit) => DropdownMenuItem(
                value: unit,
                child: Text(unit),
              ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _fromUnit = value!;
                });
              },
            ),
            const SizedBox(height: 20),
            const Text('To', style: TextStyle(fontSize: 16, color: Colors.grey)),
            DropdownButton<String>(
              value: _toUnit,
              isExpanded: true,
              items: _getUnits()
                  .map((unit) => DropdownMenuItem(
                value: unit,
                child: Text(unit),
              ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _toUnit = value!;
                });
              },
            ),
            const SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: _convert,
                child: const Text('Convert'),
              ),
            ),
            const SizedBox(height: 20),
            Center(
              child: Text(
                _result,
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}