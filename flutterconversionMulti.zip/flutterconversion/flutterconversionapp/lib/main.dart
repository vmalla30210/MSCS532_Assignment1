import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
      ),
      home: const MeasuresConverterPage(),
    );
  }
}




class MeasuresConverterPage extends StatefulWidget {
  const MeasuresConverterPage({Key? key}) : super(key: key);

  @override
  State<MeasuresConverterPage> createState() => _MeasuresConverterPageState();
}

class _MeasuresConverterPageState extends State<MeasuresConverterPage> {
  // The user-entered value in the TextField
  final TextEditingController _valueController = TextEditingController(text: '100');

  // Current category: either "Length" or "Weight"
  String _selectedCategory = 'Length';

  // Dropdown lists for length units
  final List<String> _lengthUnits = ['meters', 'kilometers', 'feet', 'miles'];
  // Dropdown lists for weight units
  final List<String> _weightUnits = ['kilograms', 'grams', 'pounds', 'ounces'];

  // Default selections
  String _fromLengthUnit = 'meters';
  String _toLengthUnit = 'feet';
  String _fromWeightUnit = 'kilograms';
  String _toWeightUnit = 'pounds';

  // Result of conversion
  String _result = '';

  // Conversion maps: convert everything to a "base" unit, then from base to target
  // For LENGTH, let's use "meters" as the base
  final Map<String, double> _lengthMap = {
    'meters': 1.0,
    'kilometers': 1000.0,
    'feet': 0.3048,
    'miles': 1609.34,
  };

  // For WEIGHT, let's use "grams" as the base
  final Map<String, double> _weightMap = {
    'grams': 1.0,
    'kilograms': 1000.0,
    'pounds': 453.59237,
    'ounces': 28.349523125,
  };

  void _convert() {
    setState(() {
      // Parse the value input
      final inputValue = double.tryParse(_valueController.text) ?? 0;

      if (_selectedCategory == 'Length') {
        // Convert from the "from" unit to meters (base), then from meters to "to" unit
        final double fromValueInMeters =
            inputValue * (_lengthMap[_fromLengthUnit] ?? 1);
        final double convertedValue =
            fromValueInMeters / (_lengthMap[_toLengthUnit] ?? 1);

        _result =
        '${inputValue.toStringAsFixed(2)} $_fromLengthUnit are ${convertedValue.toStringAsFixed(3)} $_toLengthUnit';
      } else {
        // Weight conversion
        final double fromValueInGrams =
            inputValue * (_weightMap[_fromWeightUnit] ?? 1);
        final double convertedValue =
            fromValueInGrams / (_weightMap[_toWeightUnit] ?? 1);

        _result =
        '${inputValue.toStringAsFixed(2)} $_fromWeightUnit are ${convertedValue.toStringAsFixed(3)} $_toWeightUnit';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // Depending on the chosen category, pick the correct "from" and "to" dropdowns
    final bool isLengthCategory = _selectedCategory == 'Length';
    final fromUnit = isLengthCategory ? _fromLengthUnit : _fromWeightUnit;
    final toUnit = isLengthCategory ? _toLengthUnit : _toWeightUnit;
    final unitsList = isLengthCategory ? _lengthUnits : _weightUnits;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Measures Converter'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Category toggle (Length / Weight)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('Category: '),
                DropdownButton<String>(
                  value: _selectedCategory,
                  items: const [
                    DropdownMenuItem(
                      value: 'Length',
                      child: Text('Length'),
                    ),
                    DropdownMenuItem(
                      value: 'Weight',
                      child: Text('Weight'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _selectedCategory = value;
                      });
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Value input TextField
            const Text(
              'Value',
              style: TextStyle(fontSize: 18),
            ),
            TextField(
              controller: _valueController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                hintText: 'Enter value',
              ),
            ),
            const SizedBox(height: 16),

            // "From" dropdown
            const Text(
              'From',
              style: TextStyle(fontSize: 18),
            ),
            DropdownButton<String>(
              value: fromUnit,
              items: unitsList
                  .map(
                    (unit) => DropdownMenuItem(
                  value: unit,
                  child: Text(unit),
                ),
              )
                  .toList(),
              onChanged: (value) {
                if (value != null) {
                  setState(() {
                    if (isLengthCategory) {
                      _fromLengthUnit = value;
                    } else {
                      _fromWeightUnit = value;
                    }
                  });
                }
              },
            ),
            const SizedBox(height: 16),

            // "To" dropdown
            const Text(
              'To',
              style: TextStyle(fontSize: 18),
            ),
            DropdownButton<String>(
              value: toUnit,
              items: unitsList
                  .map(
                    (unit) => DropdownMenuItem(
                  value: unit,
                  child: Text(unit),
                ),
              )
                  .toList(),
              onChanged: (value) {
                if (value != null) {
                  setState(() {
                    if (isLengthCategory) {
                      _toLengthUnit = value;
                    } else {
                      _toWeightUnit = value;
                    }
                  });
                }
              },
            ),
            const SizedBox(height: 16),

            // Convert button
            ElevatedButton(
              onPressed: _convert,
              child: const Text('Convert'),
            ),
            const SizedBox(height: 16),

            // Result
            Text(
              _result,
              style: const TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}




